# Ganti ini dengan data dari Spotify Developer Dashboard
CLIENT_ID = "4c8ea4e45b3946bb9c6ae35881fa6005"
CLIENT_SECRET = "d42aebf5106a442b909ffa52a2b2696b"
